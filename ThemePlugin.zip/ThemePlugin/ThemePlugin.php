<?php
namespace ThemePlugin;

use Shopware\Components\Plugin;

class ThemePlugin extends Plugin
{
}